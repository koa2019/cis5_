/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Danielle Fernandez
 *
 * Created on February 15, 2022, 11:49 AM
 * Purpose: First program
 * System Libraries: 
 */

#include <cstdlib>
#include <iostream>
using namespace std;

// User libraries

// Global Constants
// Physics/Chemistry/Math/Conversions

// Function prototypes

// Program execution begins here
int main(int argc, char** argv) {
    // set random number seed
    
    // declare variables
    
    // map the inputs to the outputs
    
    // Display inputs to outputs
    cout<<"Hello World"<<endl;
    
    // exit code
    return 0;
}

