/* 
 * File: main.cpp
 * Author: Danielle
 * Date: 8-24-23
 * Purpose:
 */

//System Libraries - Post Here
#include <iostream>
#include <iomanip> //setw()
using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.

//Function Prototypes - Post Here

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here when needed
    
    //Declare variables or constants here
    //7 characters or less
    int n=4;
    float a[n];
    
    //Initialize or input data here
    int i=0;
    for(i=0; i<n; i++){
        cin>>a[i];
    }
    
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    
    //Format and display outputs here
    for(i=0; i<n; i++){
        cout<<setw(9)<<setfill(' ')<<noshowpoint<<setprecision(0)<<a[i]
            <<setw(10)<<setfill(' ')<<fixed<<setprecision(1)<<a[i]
            <<setw(10)<<setfill(' ')<<setprecision(2)<<a[i];
            if(i!=n-1)cout<<endl;
    }
    //Clean up allocated memory here
    
    //Exit stage left
    return 0;
}