/* 
 * File:   main.cpp
 * Author: Danielle Fernandez
 * Created on March 5, 2022,  5:40 PM
 * Purpose: federal budget 2021 version 2
 */

// System Libraries: 
#include <iomanip>      // setprecision()
#include <iostream>
using namespace std;

// User libraries

// Global Constants
// Physics/Chemistry/Math/Conversions
const char PERCENT =100;    // Percent conversion

// Function prototypes

// Program execution begins here
int main(int argc, char** argv) {
    // set random number seed
    
    // declare variables
    float milPrct;        // military percentage
    float fedBdgt = 4.046e12f;      // federal budget $4.046 trillion https://en.wikipedia.org/wiki/2021_United_States_federal_budget
    float milBdgt = 7.535e11f;   // military budget $753.5 billion https://en.wikipedia.org/wiki/Military_budget_of_the_United_States 
    
    // map the inputs to the outputs
    milPrct = milBdgt/fedBdgt * PERCENT;     
    
    // Display inputs to outputs
    cout << "\t2021 Budget \n";
    cout<<"Military Budget = $"<< milBdgt << endl;
    cout<<"Federal Budget = $"<< fedBdgt << endl;
    cout<<"Military Budget is " << fixed << setprecision(2) << milPrct << "% of the Federal Budget. \n";

    // exit code
    return 0;
}